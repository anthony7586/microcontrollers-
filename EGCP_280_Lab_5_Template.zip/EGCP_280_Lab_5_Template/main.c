#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "msp432p401r.h"

extern int asm_main(int input);


void main() {
    int input, output;
    unsigned char bit, in, isbit, i;

    // Main Loop
    while(1) {
        printf("Enter input (4-bits): ");

        // Get input from console
        scanf ("%d",&input);

        // Get each bit from input
        // Check if binary
        in = 0;
        isbit = 1;
        for(i=0; i<=9; i++) {
            bit = input % 10;
            if(bit > 1)
                isbit = 0;
            input = input / 10;
            in += bit*(unsigned char)pow(2,(double)i);
        }

        // If input is  binary and less than 15
        // pass to assembly via R0
        if(in > 15 || !isbit) {
            printf("Please select a 4-bit input only.\n");
        } else {
            input = (int)in;
            output = asm_main(input);
            printf("Output: %d\n", output);
        }
    }

}
