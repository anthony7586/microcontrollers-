#include <stdint.h>
#include <stdio.h>
#include "msp432p401r.h"

extern void asm_main();

void main() {
    asm_main();
}
